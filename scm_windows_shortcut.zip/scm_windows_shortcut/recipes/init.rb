class scm_windows_shortcut {
}